# coding: utf-8
# 2019/12/17 @ tongshiwei

from .KnowledgeTracing import build_interactions, select_n_most_active
