# coding: utf-8
# 2019/12/6 @ tongshiwei

from .KnowledgeTracing import transfer_synthetic_dataset
