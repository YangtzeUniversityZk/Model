# coding: utf-8
# create by tongshiwei on 2019-8-16


from .download_data import URL_DICT
