DataSet
==============================

ASSISTments
------------------------------
.. nbgallery::
    :caption: ASSISTments
    :name: assistment_gallery
    :glob:

    Analysis for ASSISTments2009-2010 <../../build/blitz/ASSISTments/ASSISTments2009-2010>

    Analysis for ASSISTments2015 <../../build/blitz/ASSISTments/ASSISTments2015>

    Analysis for ASSISTments2017 <../../build/blitz/ASSISTments/ASSISTments2017>


EdNet
------------------------------

.. nbgallery::
    :caption: EdNet_KT1
    :name: ednet_gallery
    :glob:

    Analysis for EdNet <../../build/blitz/EdNet_KT1/EdNet_KT1>

junyi
------------------------------

.. nbgallery::
    :caption: junyi
    :name: junyi_gallery
    :glob:

    Analysis for junyi <../../build/blitz/junyi/junyi>

math2015
------------------------------

.. nbgallery::
    :caption: math2015
    :name: math2015_gallery
    :glob:

    Analysis for math2015-Math1 <../../build/blitz/math2015/Math1>
    Analysis for math2015-Math2 <../../build/blitz/math2015/Math2>

OLI_Fall2011
------------------------------

.. nbgallery::
    :caption: OLI_Fall2011
    :name: oli_fall_2011_gallery
    :glob:

    Analysis for OLI_FALL2011-problem <../../build/blitz/OLI_Fall2011/OLI_2011F_problem>
    Analysis for OLI_FALL2011-step <../../build/blitz/OLI_Fall2011/OLI_2011F_step>
    Analysis for OLI_FALL2011-transaction <../../build/blitz/OLI_Fall2011/OLI_2011F_transaction>

KDD Cup 2010
------------------------------

.. nbgallery::
    :caption: KDD Cup 2010
    :name: kdd_cup_2010_gallery
    :glob:

    Analysis for KDD Cup 2010 <../../build/blitz/KDD Cup 2010>

Math23k
------------------------------

.. nbgallery::
    :caption: Math23k
    :name: Math23k_gallery
    :glob:

    Analysis for Math23k <../../build/blitz/Math23k_Analysis_Report>

pisa2015math
------------------------------

.. nbgallery::
    :caption: pisa2015math
    :name: pisa2015math_gallery
    :glob:

    Analysis for pisa2014math <../../build/blitz/pisa2015math>