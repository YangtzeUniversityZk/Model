EduData.Task
======================

.. automodule:: EduData.Task.KnowledgeTracing.format
   :members:
   :imported-members:

.. automodule:: EduData.Task.KnowledgeTracing.graph
   :members:
   :imported-members:
