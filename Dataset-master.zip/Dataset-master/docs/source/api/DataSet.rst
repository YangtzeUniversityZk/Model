EduData.DataSet
============================

EduData.DataSet.download_data
----------------------

.. automodule:: EduData.DataSet
   :members:
   :imported-members:

.. automodule:: EduData.DataSet.junyi.KnowledgeTracing
   :members:
   :imported-members:

.. automodule:: EduData.DataSet.download_data.download_data.download_data
   :members:
   :imported-members:

.. automodule:: EduData.DataSet.EdNet.utils
   :members:
   :imported-members:
