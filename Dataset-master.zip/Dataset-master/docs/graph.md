# Constructing Knowledge graph

## Reference
[1] Piech C, Bassen J, Huang J, et al. Deep knowledge tracing[C]//Advances in neural information processing systems. 2015: 505-513.

[2] Nakagawa H, Iwasawa Y, Matsuo Y. Graph-based Knowledge Tracing: Modeling Student Proficiency Using Graph Neural Network[C]//IEEE/WIC/ACM International Conference on Web Intelligence. ACM, 2019: 156-163.

