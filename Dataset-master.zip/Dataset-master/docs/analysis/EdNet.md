# EdNet

## EdNet-KT1

* Some findings:
    * The interactions in uxxxx.csv is time increasing.
    * 782974 students
    * 13169 questions
In order to form the question-response sequence, we need to check the user answer with real answer

### EdNet-KT1-Mini

Selected 1000 most active students with `12274` different questions and
```text
records number: 9584614
correct records number: 6816346
```

