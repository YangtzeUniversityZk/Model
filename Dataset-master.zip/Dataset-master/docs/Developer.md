# The guidance for developer

## Create new dataset

### pytest

Add a new `test_dataset.py` under `tests` directory. 
Make sure a special `url` link using for test is provided in order to avoid large file downloading.
 