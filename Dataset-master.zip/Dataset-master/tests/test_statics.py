# coding: utf-8
# 2019/12/13 @ tongshiwei

# redirect to test_junyi.py
